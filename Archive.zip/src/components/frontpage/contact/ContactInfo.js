import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function ContactInfo() {
  return (
    <div className="App d-flex flex-column align-items-center justify-content-center w-100">
      <h1>Contact Information</h1>
    </div>
  );
}

export default ContactInfo;
